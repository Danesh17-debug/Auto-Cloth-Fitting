bl_info = {
    "name": "Auto Cloth Fitting",
    "author": "Danesh Sharman",
    "version": (1, 0, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Cloth",
    "description": "Automatically fits and simulates cloth to a target object",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy

class CLOTH_OT_FitAndSimulate(bpy.types.Operator):
    """Automatically fit and simulate cloth to the target object"""
    bl_idname = "cloth.auto_fit_sim"
    bl_label = "Fit & Simulate Cloth"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object  # Get the selected cloth object

        if not obj:
            self.report({'ERROR'}, "No active object selected!")
            return {'CANCELLED'}

        if obj.type != 'MESH':
            self.report({'ERROR'}, "Selected object is not a mesh!")
            return {'CANCELLED'}

        scene = context.scene
        target = scene.target_object

        if not target:
            self.report({'WARNING'}, "Target object not set!")
            return {'CANCELLED'}

        if obj == target:
            self.report({'ERROR'}, "Cloth object cannot be its own target!")
            return {'CANCELLED'}

        self.auto_fit(obj, target, scene)
        self.setup_cloth_simulation(obj, target, scene)

        self.report({'INFO'}, "Cloth fitting and simulation applied successfully.")
        return {'FINISHED'}

    def auto_fit(self, cloth_obj, target, scene):
        """Adjust the cloth to fit the target object using Shrinkwrap"""
        for mod in cloth_obj.modifiers:
            if mod.type == 'SHRINKWRAP':
                cloth_obj.modifiers.remove(mod)

        shrinkwrap = cloth_obj.modifiers.new(name="AutoFit", type='SHRINKWRAP')
        shrinkwrap.target = target
        shrinkwrap.wrap_method = scene.shrinkwrap_method
        shrinkwrap.offset = scene.shrinkwrap_offset

    def setup_cloth_simulation(self, cloth_obj, target, scene):
        """Configure cloth physics for simulation"""
        cloth_mod = cloth_obj.modifiers.get("ClothSim")
        if not cloth_mod:
            cloth_mod = cloth_obj.modifiers.new(name="ClothSim", type='CLOTH')

        cloth_mod.settings.quality = scene.cloth_quality
        cloth_mod.settings.mass = scene.cloth_mass
        cloth_mod.settings.bending_stiffness = scene.cloth_bending
        cloth_mod.settings.air_damping = scene.cloth_air_damping
        cloth_mod.settings.use_self_collision = scene.enable_self_collision
        cloth_mod.settings.structural_stiffness = scene.structural_stiffness
        cloth_mod.settings.damping = scene.cloth_damping

        if scene.enable_collision:
            col_mod = target.modifiers.get("ClothCollision")
            if not col_mod:
                col_mod = target.modifiers.new(name="ClothCollision", type='COLLISION')
            col_mod.settings.friction = scene.collision_friction


class CLOTH_PT_Panel(bpy.types.Panel):
    """UI Panel for the Auto Cloth Addon"""
    bl_label = "Auto Cloth Fitting"
    bl_idname = "CLOTH_PT_Fitting"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Cloth'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "target_object", text="Target Object")

        layout.separator()
        layout.label(text="Shrinkwrap Settings:")
        layout.prop(scene, "shrinkwrap_method", text="Wrap Method")
        layout.prop(scene, "shrinkwrap_offset", text="Offset")

        layout.separator()
        layout.label(text="Cloth Simulation Settings:")
        layout.prop(scene, "enable_self_collision", text="Enable Self-Collision")
        layout.prop(scene, "structural_stiffness", text="Structural Stiffness")
        layout.prop(scene, "cloth_damping", text="Damping")

        layout.separator()
        layout.label(text="Collision Settings:")
        layout.prop(scene, "enable_collision", text="Enable Collision for Target")
        layout.prop(scene, "collision_friction", text="Friction")

        layout.separator()
        layout.operator("cloth.auto_fit_sim", text="Fit & Simulate Cloth")


def register():
    try:
        bpy.utils.register_class(CLOTH_OT_FitAndSimulate)
        bpy.utils.register_class(CLOTH_PT_Panel)

        bpy.types.Scene.target_object = bpy.props.PointerProperty(
            type=bpy.types.Object, name="Target Object", description="Object to fit cloth to"
        )
        bpy.types.Scene.shrinkwrap_method = bpy.props.EnumProperty(
            name="Wrap Method",
            description="Choose shrinkwrap method",
            items=[
                ('NEAREST_SURFACEPOINT', "Nearest Surface", ""),
                ('PROJECT', "Project", ""),
                ('NEAREST_VERTEX', "Nearest Vertex", "")
            ],
            default='PROJECT'
        )
        bpy.types.Scene.shrinkwrap_offset = bpy.props.FloatProperty(
            name="Offset",
            description="Cloth offset distance from target",
            default=0.01,
            min=0.0, max=1.0
        )
        bpy.types.Scene.enable_self_collision = bpy.props.BoolProperty(
            name="Enable Self-Collision",
            description="Allow cloth to collide with itself",
            default=True
        )
        bpy.types.Scene.structural_stiffness = bpy.props.FloatProperty(
            name="Structural Stiffness",
            description="How stiff the cloth structure is",
            default=15.0, min=0.0, max=50.0
        )
        bpy.types.Scene.cloth_damping = bpy.props.FloatProperty(
            name="Damping",
            description="Damping factor for cloth motion",
            default=0.5, min=0.0, max=1.0
        )
        bpy.types.Scene.enable_collision = bpy.props.BoolProperty(
            name="Enable Collision for Target",
            description="Enable collision physics on the target object",
            default=True
        )
        bpy.types.Scene.collision_friction = bpy.props.FloatProperty(
            name="Friction",
            description="Friction for cloth collision",
            default=5.0, min=0.0, max=50.0
        )
    except Exception as e:
        print(f"Error registering add-on: {e}")


def unregister():
    try:
        bpy.utils.unregister_class(CLOTH_OT_FitAndSimulate)
        bpy.utils.unregister_class(CLOTH_PT_Panel)

        del bpy.types.Scene.target_object
        del bpy.types.Scene.shrinkwrap_method
        del bpy.types.Scene.shrinkwrap_offset
        del bpy.types.Scene.enable_self_collision
        del bpy.types.Scene.structural_stiffness
        del bpy.types.Scene.cloth_damping
        del bpy.types.Scene.enable_collision
        del bpy.types.Scene.collision_friction
    except Exception as e:
        print(f"Error unregistering add-on: {e}")


if __name__ == "__main__":
    register()
