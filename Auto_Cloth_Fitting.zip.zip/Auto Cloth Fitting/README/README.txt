# Auto-Cloth Fitting Add-on

## Features:
✔️ Auto-fits cloth to target objects  
✔️ Configurable cloth simulation settings  
✔️ Collision and shrinkwrap options  

## Installation:
1. Download `Auto_Cloth_Fitting.zip`
2. In Blender, go to `Edit > Preferences > Add-ons`
3. Click `Install...`, select the ZIP file, and enable the add-on

## How to Use:
1. Select your cloth object.
2. In the Sidebar (`N` panel), go to `Cloth` tab.
3. Choose a `Target Object` and click `Fit & Simulate`.
